speed
1/0s
usr/local/install
set/speed/server/1s
checking...
speed installed
checking server speed status...
speed 1/5s
ping 23/s

